# Limpeza de textos da interface

Foram removidas da interface do aplicativo as frases que citavam diagramas, casos de uso ou implementação acadêmica.

## Arquivo principal alterado

- `App.js`

## Também ajustado

- `server.js`
  - Comentários das rotas foram deixados mais neutros.

## Observação

Os arquivos de documentação, como `MAPEAMENTO-DIAGRAMAS.md` e `TESTES-UNITARIOS.md`, podem continuar mencionando diagramas e testes, porque não aparecem para o usuário final do app.
