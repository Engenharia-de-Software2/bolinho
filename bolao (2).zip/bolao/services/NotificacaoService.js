import { v4 as uuidv4 } from "uuid";
import { db } from "../database.js";

class NotificacaoService {
  notificarResultado(partida) {
    // registrarNotificacao(usuarios)
    const notificacao = {
      id: uuidv4(),
      tipo: "RESULTADO_PARTIDA",
      titulo: "Resultado Atualizado",
      mensagem: `A partida ${partida.time_a} x ${partida.time_b} foi finalizada com o placar ${partida.resultado_a}x${partida.resultado_b}.`,
      bolao_id: partida.bolao_id,
      lida: false,
    };

    db.registrarNotificacao(notificacao);
    return notificacao;
  }
}

export default new NotificacaoService();
