# Mapeamento dos 5 casos de uso para o código

Esta versão foi ajustada para seguir os 5 diagramas informados, mantendo a pasta raiz `bolao/` e os nomes principais dos arquivos.

## 1 - Cadastrar-se

Diagrama de projeto:

`AppFrontend -> AuthController : POST /auth/register(nome, email, senha)`

Código:

- `App.js`: função `cadastrarSe()`
- `server.js`: `app.post("/auth/register", AuthController.register)`
- `controllers/AuthController.js`: método `register(req, res)`
- `database.js`: `registrarUsuario(usuario)`

Fluxo implementado:

1. App envia `nome`, `email` e `senha`.
2. Controller valida dados.
3. Controller gera `senhaHash`.
4. Controller cria objeto `Usuario`.
5. Database registra usuário.
6. Controller gera token.
7. API retorna `201 Created { token, usuario }`.
8. App redireciona para o menu principal.

## 2 - Fazer Login

Diagrama de projeto:

`AppFrontend -> AuthController : POST /auth/login(email, senha)`

Código:

- `App.js`: função `fazerLogin()`
- `server.js`: `app.post("/auth/login", AuthController.login)`
- `controllers/AuthController.js`: método `login(req, res)`
- `database.js`: `buscarUsuario(email)`

Fluxo implementado:

1. App envia `email` e `senha`.
2. Controller busca usuário no banco.
3. Controller compara senha com hash simplificado.
4. Se válido, gera token e retorna `200 OK { token, usuario }`.
5. Se inválido, retorna `401 Unauthorized` e o App exibe erro.

## 3 - Criar Bolão

Diagrama de projeto:

`AppFrontend -> BoloesController : POST /boloes(dados, token)`

Código:

- `App.js`: função `criarBolao()`
- `server.js`: `app.post("/boloes", authMiddleware, BoloesController.criar)`
- `authMiddleware.js`: valida token
- `controllers/BoloesController.js`: método `criar(req, res)`
- `database.js`: `registrarBolao(bolao)`

Fluxo implementado:

1. App envia dados do bolão com token.
2. Middleware valida token.
3. Controller valida `nome` e `tipo`.
4. Controller gera código de convite.
5. Controller cria objeto `Bolao`.
6. Database registra bolão.
7. API retorna `201 Created { bolao, codigo_convite }`.
8. App exibe o código do bolão.

Observação: para permitir testar o caso de uso `Definir Resultados` sem criar um sexto diagrama, o backend cria uma partida padrão vinculada ao bolão criado.

## 4 - Excluir Bolão

Diagrama de projeto:

`AppFrontend -> BoloesController : DELETE /boloes/{id}(token)`

Código:

- `App.js`: função `excluirBolao()`
- `server.js`: `app.delete("/boloes/:id", authMiddleware, BoloesController.excluir)`
- `authMiddleware.js`: valida token
- `controllers/BoloesController.js`: método `excluir(req, res)`
- `database.js`: `buscarBolao(id)` e `excluirBolao(bolao)`

Fluxo implementado:

1. App solicita exclusão com token.
2. Middleware valida token.
3. Controller busca o bolão.
4. Controller verifica se `criador_id == usuario.id`.
5. Se autorizado, exclui bolão e retorna `200 OK`.
6. Se não autorizado, retorna `403 Forbidden`.

## 5 - Definir Resultados

Diagrama de projeto:

`AppFrontend -> PartidasController : PUT /partidas/{id}/resultado(placar, token)`

Código:

- `App.js`: função `definirResultados(partida)`
- `server.js`: `app.put("/partidas/:id/resultado", authMiddleware, PartidasController.atualizarResultado)`
- `authMiddleware.js`: valida token
- `controllers/PartidasController.js`: método `atualizarResultado(req, res)`
- `controllers/ApostasController.js`: método `calcularPontuacao(partida)`
- `services/NotificacaoService.js`: método `notificarResultado(partida)`
- `database.js`: `buscarPartida`, `editarPartida`, `buscarApostas`, `atualizarPontos`, `registrarNotificacao`

Fluxo implementado:

1. App envia placar com token.
2. Middleware valida token.
3. Controller busca partida.
4. Controller verifica se o usuário é criador do bolão.
5. Controller edita partida com `status = finalizada`.
6. `ApostasController` calcula pontuação.
7. `NotificacaoService` registra notificação.
8. API retorna `200 OK { resultado, ranking atualizado }`.
9. App exibe resultado e ranking.

## Fora dos 5 diagramas

Os fluxos de `entrar no bolão por código` e `convidar pessoas` existem nos documentos antigos do Bolinho, mas não estavam na lista de 5 casos que você pediu agora. Por isso, esta versão não colocou esses fluxos como requisito principal, para não divergir dos diagramas cobrados.
