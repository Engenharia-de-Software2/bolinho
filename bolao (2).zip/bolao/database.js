import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DB_FILE = path.join(__dirname, "db-data.json");

const estadoInicial = {
  usuarios: [],
  boloes: [],
  participantes: [],
  partidas: [],
  apostas: [],
  notificacoes: [],
};

class Database {
  constructor() {
    this.usuarios = [];
    this.boloes = [];
    this.participantes = [];
    this.partidas = [];
    this.apostas = [];
    this.notificacoes = [];
    this.carregar();
  }

  carregar() {
    if (!fs.existsSync(DB_FILE)) {
      Object.assign(this, JSON.parse(JSON.stringify(estadoInicial)));
      return;
    }

    try {
      const dados = JSON.parse(fs.readFileSync(DB_FILE, "utf8"));
      this.usuarios = dados.usuarios || [];
      this.boloes = dados.boloes || [];
      this.participantes = dados.participantes || [];
      this.partidas = dados.partidas || [];
      this.apostas = dados.apostas || [];
      this.notificacoes = dados.notificacoes || [];
    } catch (error) {
      console.warn("Não foi possível carregar db-data.json:", error.message);
      Object.assign(this, JSON.parse(JSON.stringify(estadoInicial)));
    }
  }

  salvar() {
    const dados = {
      usuarios: this.usuarios,
      boloes: this.boloes,
      participantes: this.participantes,
      partidas: this.partidas,
      apostas: this.apostas,
      notificacoes: this.notificacoes,
    };

    fs.writeFileSync(DB_FILE, JSON.stringify(dados, null, 2), "utf8");
  }

  // Métodos usados nos diagramas de autenticação.
  buscarUsuario(email) {
    return this.usuarios.find((u) => u.email === email);
  }

  buscarUsuarioPorId(id) {
    return this.usuarios.find((u) => u.id === id);
  }

  registrarUsuario(usuario) {
    this.usuarios.push(usuario);
    this.salvar();
    return usuario.id;
  }

  // Métodos usados nos diagramas de bolão.
  registrarBolao(bolao) {
    this.boloes.push(bolao);

    // O criador entra automaticamente no próprio bolão para a tela conseguir exibir o registro criado.
    this.participantes.push({ bolao_id: bolao.id, usuario_id: bolao.criador_id });

    this.salvar();
    return bolao.id;
  }

  buscarBolao(id) {
    return this.boloes.find((b) => b.id === id);
  }

  excluirBolao(bolao) {
    this.boloes = this.boloes.filter((b) => b.id !== bolao.id);
    this.participantes = this.participantes.filter((p) => p.bolao_id !== bolao.id);
    this.partidas = this.partidas.filter((p) => p.bolao_id !== bolao.id);
    this.apostas = this.apostas.filter((a) => a.bolao_id !== bolao.id);
    this.notificacoes = this.notificacoes.filter((n) => n.bolao_id !== bolao.id);
    this.recalcularPontosTotais();
    this.salvar();
  }

  // Métodos usados no diagrama Definir Resultados.
  buscarPartida(id) {
    return this.partidas.find((p) => p.id === id);
  }

  editarPartida(id, resultado_a, resultado_b, status = "finalizada") {
    const partida = this.buscarPartida(id);
    if (!partida) return null;

    partida.resultado_a = resultado_a;
    partida.resultado_b = resultado_b;
    partida.status = status;
    this.salvar();
    return partida;
  }

  buscarApostas(partida_id) {
    return this.apostas.filter((a) => a.partida_id === partida_id);
  }

  atualizarPontos(aposta, pontos) {
    aposta.pontos = pontos;
    this.recalcularPontosTotais();
    this.salvar();
    return aposta;
  }

  registrarNotificacao(notificacao) {
    this.notificacoes.push(notificacao);
    this.salvar();
    return notificacao.id;
  }

  ranking() {
    return this.usuarios
      .map((u) => ({ nome: u.nome, email: u.email, pontos: u.pontos_totais || 0 }))
      .sort((a, b) => b.pontos - a.pontos);
  }

  usuariosPublicos() {
    return this.usuarios.map(({ senha, ...usuario }) => usuario);
  }

  recalcularPontosTotais() {
    this.usuarios = this.usuarios.map((usuario) => {
      const pontos_totais = this.apostas
        .filter((aposta) => aposta.usuario_id === usuario.id)
        .reduce((soma, aposta) => soma + (aposta.pontos || 0), 0);

      return { ...usuario, pontos_totais };
    });
  }
}

export const db = new Database();
