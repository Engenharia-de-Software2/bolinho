import jwt from "jsonwebtoken";
import { v4 as uuidv4 } from "uuid";
import { db } from "../database.js";

export const JWT_SECRET = "super-secret-key";

function usuarioPublico(usuario) {
  const { senha, ...dadosPublicos } = usuario;
  return dadosPublicos;
}

class AuthController {
  async register(req, res) {
    const { nome, email, senha } = req.body;
    const emailNormalizado = String(email || "").trim().toLowerCase();

    // validaDados(nome, email, senha)
    const emailValido = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailNormalizado);
    if (!nome || !emailValido || !senha) {
      return res.status(400).json({ message: "Campos inválidos" });
    }

    if (db.buscarUsuario(emailNormalizado)) {
      return res.status(409).json({ message: "E-mail já cadastrado" });
    }

    // hashPassword(senha) -> simplificado para protótipo acadêmico
    const senhaHash = `hash_${senha}`;

    // new Usuario(nome, email, senhaHash)
    const novoUsuario = {
      id: uuidv4(),
      nome: String(nome).trim(),
      email: emailNormalizado,
      senha: senhaHash,
      role: "user",
      pontos_totais: 0,
    };

    // registrarUsuario(usuario)
    db.registrarUsuario(novoUsuario);

    // generateToken(usuario)
    const token = jwt.sign({ id: novoUsuario.id }, JWT_SECRET, { expiresIn: "12h" });

    // 201 Created { token, usuario }
    return res.status(201).json({ token, usuario: usuarioPublico(novoUsuario) });
  }

  async login(req, res) {
    const { email, senha } = req.body;
    const emailNormalizado = String(email || "").trim().toLowerCase();

    // buscarUsuario(email)
    const usuario = db.buscarUsuario(emailNormalizado);

    // comparePassword(senha, hash)
    const senhaValida = !!usuario && usuario.senha === `hash_${senha}`;

    if (!senhaValida) {
      // 401 Unauthorized
      return res.status(401).json({ message: "Usuário ou senha inválidos" });
    }

    // generateToken(usuario)
    const token = jwt.sign({ id: usuario.id }, JWT_SECRET, { expiresIn: "12h" });

    // 200 OK { token, usuario }
    return res.status(200).json({ token, usuario: usuarioPublico(usuario) });
  }
}

export default new AuthController();
