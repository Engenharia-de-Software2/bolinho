class AdminController {
  // Componente reservado para manter compatibilidade com o diagrama de componentes da fase de análise.
}

export default new AdminController();
