import { db } from "../database.js";
import ApostasController from "./ApostasController.js";
import NotificacaoService from "../services/NotificacaoService.js";

class PartidasController {
  async atualizarResultado(req, res) {
    const { id } = req.params;
    const { resultado_a, resultado_b } = req.body;

    // buscarPartida(id)
    const partida = db.buscarPartida(id);
    if (!partida) {
      return res.status(404).json({ message: "Partida não encontrada" });
    }

    const bolao = db.buscarBolao(partida.bolao_id);
    if (!bolao) {
      return res.status(404).json({ message: "Bolão não encontrado" });
    }

    // verifica se usuario e o criador do bolao
    if (bolao.criador_id !== req.usuario.id) {
      return res.status(403).json({ message: "Erro de permissão" });
    }

    const placarA = parseInt(resultado_a, 10);
    const placarB = parseInt(resultado_b, 10);

    if (Number.isNaN(placarA) || Number.isNaN(placarB)) {
      return res.status(400).json({ message: "Resultado inválido" });
    }

    // editarPartida(resultado_a, resultado_b, status=finalizada)
    const partidaAtualizada = db.editarPartida(id, placarA, placarB, "finalizada");

    // calcularPontuacao(partida)
    ApostasController.calcularPontuacao(partidaAtualizada);

    // notificarResultado(partida) -> registrarNotificacao(usuarios)
    NotificacaoService.notificarResultado(partidaAtualizada);

    // 200 OK { resultado, ranking atualizado }
    return res.status(200).json({
      message: "Partida finalizada e pontuações calculadas.",
      resultado: {
        resultado_a: partidaAtualizada.resultado_a,
        resultado_b: partidaAtualizada.resultado_b,
        status: partidaAtualizada.status,
      },
      partida: partidaAtualizada,
      ranking: db.ranking(),
    });
  }
}

export default new PartidasController();
