import { db } from "../database.js";

class ApostasController {
  calcularPontuacao(partida) {
    // buscarApostas(partida_id)
    const apostas = db.buscarApostas(partida.id);

    // loop para cada aposta
    apostas.forEach((aposta) => {
      let pontos = 0;

      // compara placar_apostado com resultado
      if (
        aposta.placar_time_a === partida.resultado_a &&
        aposta.placar_time_b === partida.resultado_b
      ) {
        pontos = 10;
      } else if (
        Math.sign(aposta.placar_time_a - aposta.placar_time_b) ===
        Math.sign(partida.resultado_a - partida.resultado_b)
      ) {
        pontos = 5;
      }

      // atualizarPontos(aposta, pontos)
      db.atualizarPontos(aposta, pontos);
    });

    return apostas;
  }
}

export default new ApostasController();
