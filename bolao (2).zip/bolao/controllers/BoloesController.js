import { v4 as uuidv4 } from "uuid";
import { db } from "../database.js";

function gerarCodigo() {
  return Math.random().toString(36).substring(2, 8).toUpperCase();
}

class BoloesController {
  async criar(req, res) {
    const { nome, tipo, descricao } = req.body;

    // validaDados(nome, tipo, ...)
    if (!nome || !String(nome).trim() || !tipo || !String(tipo).trim()) {
      return res.status(400).json({ message: "Nome e tipo são obrigatórios" });
    }

    // gerarCodigo()
    let codigo_convite = gerarCodigo();
    while (db.boloes.some((b) => b.codigo_convite === codigo_convite)) {
      codigo_convite = gerarCodigo();
    }

    // new Bolao(nome, tipo, criador_id, codigo_convite)
    const novoBolao = {
      id: uuidv4(),
      nome: String(nome).trim(),
      descricao: String(descricao || "").trim(),
      tipo: String(tipo).trim(),
      codigo_convite,
      criador_id: req.usuario.id,
      status: "ativo",
    };

    // registrarBolao(bolao)
    db.registrarBolao(novoBolao);

    // Dado de apoio para permitir testar o caso de uso "Definir Resultados" sem criar outro diagrama.
    db.partidas.push({
      id: `${novoBolao.id}-partida-1`,
      bolao_id: novoBolao.id,
      time_a: "Time A",
      time_b: "Time B",
      data_hora: "Data a definir",
      resultado_a: null,
      resultado_b: null,
      status: "agendada",
    });
    db.salvar();

    // 201 Created { bolao, codigo_convite }
    return res.status(201).json({ bolao: novoBolao, codigo_convite });
  }

  async excluir(req, res) {
    const { id } = req.params;

    // buscarBolao(id)
    const bolao = db.buscarBolao(id);
    if (!bolao) {
      return res.status(404).json({ message: "Bolão não encontrado" });
    }

    // verifica criador_id == usuario.id
    if (bolao.criador_id !== req.usuario.id) {
      // 403 Forbidden
      return res.status(403).json({ message: "Erro de permissão" });
    }

    // excluirBolao(bolao)
    db.excluirBolao(bolao);

    // 200 OK
    return res.status(200).json({ message: "Bolão excluído com sucesso" });
  }
}

export default new BoloesController();
