# Testes unitarios adicionados

Foram adicionados testes automatizados usando o test runner nativo do Node.js.

## Arquivos adicionados

- `tests/bolao.test.js`
- `tests/README.md`

## Arquivos alterados

- `server.js`
  - Agora exporta o `app` Express.
  - Continua iniciando o servidor normalmente quando executado por `npm run server`.
- `package.json`
  - Adicionado script `npm test`.

## Casos testados

- Cadastrar-se
- Fazer Login
- Criar Bolao
- Excluir Bolao
- Definir Resultados

## Comando

```bash
npm install
npm test
```
