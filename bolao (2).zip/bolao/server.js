import express from "express";
import { fileURLToPath } from "url";
import { authMiddleware } from "./authMiddleware.js";
import AuthController from "./controllers/AuthController.js";
import BoloesController from "./controllers/BoloesController.js";
import PartidasController from "./controllers/PartidasController.js";

const app = express();

app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET,POST,PUT,DELETE,OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
  if (req.method === "OPTIONS") return res.sendStatus(204);
  return next();
});

app.use(express.json());

app.get("/health", (req, res) => {
  res.status(200).json({ ok: true, message: "Servidor do Bolão ativo" });
});

// Cadastro de usuário
app.post("/auth/register", AuthController.register);

// Login de usuário
app.post("/auth/login", AuthController.login);

// Criação de bolão
app.post("/boloes", authMiddleware, BoloesController.criar);

// Exclusão de bolão
app.delete("/boloes/:id", authMiddleware, BoloesController.excluir);

// Definição de resultados
app.put("/partidas/:id/resultado", authMiddleware, PartidasController.atualizarResultado);

const PORT = process.env.PORT || 3000;
const isMainModule = process.argv[1] === fileURLToPath(import.meta.url);

if (isMainModule) {
  app.listen(PORT, () => {
    console.log(`Servidor rodando com sucesso na porta ${PORT}`);
  });
}

export default app;
