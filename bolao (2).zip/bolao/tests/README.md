# Testes unitarios do Bolao

Esta pasta contem testes automatizados para os 5 casos de uso principais do projeto:

1. Cadastrar-se
2. Fazer Login
3. Criar Bolao
4. Excluir Bolao
5. Definir Resultados

## Como rodar

Na pasta `bolao`, execute:

```bash
npm install
npm test
```

Os testes usam o test runner nativo do Node.js (`node --test`), por isso nao precisam de Jest, Supertest ou outras bibliotecas extras.
