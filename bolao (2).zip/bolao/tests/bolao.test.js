import test from "node:test";
import assert from "node:assert/strict";
import app from "../server.js";
import { db } from "../database.js";

let servidor;
let baseUrl;

function resetarBancoDeTeste() {
  db.usuarios = [];
  db.boloes = [];
  db.participantes = [];
  db.partidas = [];
  db.apostas = [];
  db.notificacoes = [];
  db.salvar();
}

async function requisicao(rota, { metodo = "GET", token = null, body = null } = {}) {
  const resposta = await fetch(`${baseUrl}${rota}`, {
    method: metodo,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });

  const texto = await resposta.text();
  const dados = texto ? JSON.parse(texto) : {};
  return { status: resposta.status, dados };
}

async function cadastrarUsuario({
  nome = "Usuario Teste",
  email = "teste@email.com",
  senha = "123456",
} = {}) {
  return requisicao("/auth/register", {
    metodo: "POST",
    body: { nome, email, senha },
  });
}

async function criarBolao(token, dados = {}) {
  return requisicao("/boloes", {
    metodo: "POST",
    token,
    body: {
      nome: "Bolao Teste",
      tipo: "Copa",
      descricao: "Bolao criado durante teste automatizado",
      ...dados,
    },
  });
}

test.before(async () => {
  servidor = app.listen(0);
  await new Promise((resolve) => servidor.once("listening", resolve));
  const { port } = servidor.address();
  baseUrl = `http://127.0.0.1:${port}`;
});

test.after(async () => {
  resetarBancoDeTeste();
  await new Promise((resolve, reject) => {
    servidor.close((erro) => (erro ? reject(erro) : resolve()));
  });
});

test.beforeEach(() => {
  resetarBancoDeTeste();
});

test("health check deve indicar servidor ativo", async () => {
  const { status, dados } = await requisicao("/health");

  assert.equal(status, 200);
  assert.equal(dados.ok, true);
});

test("Cadastrar-se deve criar usuario, devolver token e nao expor senha", async () => {
  const { status, dados } = await cadastrarUsuario();

  assert.equal(status, 201);
  assert.ok(dados.token);
  assert.equal(dados.usuario.nome, "Usuario Teste");
  assert.equal(dados.usuario.email, "teste@email.com");
  assert.equal(dados.usuario.senha, undefined);
  assert.equal(db.usuarios.length, 1);
});

test("Cadastrar-se deve bloquear e-mail duplicado", async () => {
  await cadastrarUsuario();
  const { status, dados } = await cadastrarUsuario();

  assert.equal(status, 409);
  assert.match(dados.message, /E-mail já cadastrado/i);
});

test("Cadastrar-se deve rejeitar campos invalidos", async () => {
  const { status, dados } = await cadastrarUsuario({
    nome: "",
    email: "email-invalido",
    senha: "",
  });

  assert.equal(status, 400);
  assert.match(dados.message, /Campos inválidos/i);
});

test("Fazer Login deve autenticar usuario cadastrado", async () => {
  await cadastrarUsuario({
    email: "login@email.com",
    senha: "senha-correta",
  });

  const { status, dados } = await requisicao("/auth/login", {
    metodo: "POST",
    body: {
      email: "login@email.com",
      senha: "senha-correta",
    },
  });

  assert.equal(status, 200);
  assert.ok(dados.token);
  assert.equal(dados.usuario.email, "login@email.com");
});

test("Fazer Login deve rejeitar senha incorreta", async () => {
  await cadastrarUsuario({
    email: "login@email.com",
    senha: "senha-correta",
  });

  const { status, dados } = await requisicao("/auth/login", {
    metodo: "POST",
    body: {
      email: "login@email.com",
      senha: "senha-errada",
    },
  });

  assert.equal(status, 401);
  assert.match(dados.message, /Usuário ou senha inválidos/i);
});

test("Criar Bolao deve cadastrar bolao, participante criador e partida inicial", async () => {
  const cadastro = await cadastrarUsuario();
  const token = cadastro.dados.token;

  const { status, dados } = await criarBolao(token);

  assert.equal(status, 201);
  assert.equal(dados.bolao.nome, "Bolao Teste");
  assert.equal(dados.bolao.tipo, "Copa");
  assert.ok(dados.codigo_convite);
  assert.equal(db.boloes.length, 1);
  assert.equal(db.participantes.length, 1);
  assert.equal(db.partidas.length, 1);
  assert.equal(db.partidas[0].bolao_id, dados.bolao.id);
});

test("Criar Bolao deve exigir token", async () => {
  const { status, dados } = await criarBolao(null);

  assert.equal(status, 401);
  assert.match(dados.message, /Token não fornecido/i);
});

test("Criar Bolao deve rejeitar nome ou tipo vazios", async () => {
  const cadastro = await cadastrarUsuario();
  const token = cadastro.dados.token;

  const { status, dados } = await criarBolao(token, { nome: "", tipo: "" });

  assert.equal(status, 400);
  assert.match(dados.message, /Nome e tipo são obrigatórios/i);
});

test("Excluir Bolao deve permitir exclusao pelo criador", async () => {
  const cadastro = await cadastrarUsuario();
  const token = cadastro.dados.token;
  const criado = await criarBolao(token);
  const bolaoId = criado.dados.bolao.id;

  const { status, dados } = await requisicao(`/boloes/${bolaoId}`, {
    metodo: "DELETE",
    token,
  });

  assert.equal(status, 200);
  assert.match(dados.message, /Bolão excluído com sucesso/i);
  assert.equal(db.boloes.length, 0);
  assert.equal(db.partidas.length, 0);
});

test("Excluir Bolao deve bloquear usuario que nao e criador", async () => {
  const dono = await cadastrarUsuario({
    nome: "Dono",
    email: "dono@email.com",
    senha: "123456",
  });
  const criado = await criarBolao(dono.dados.token);

  const outro = await cadastrarUsuario({
    nome: "Outro",
    email: "outro@email.com",
    senha: "123456",
  });

  const { status, dados } = await requisicao(`/boloes/${criado.dados.bolao.id}`, {
    metodo: "DELETE",
    token: outro.dados.token,
  });

  assert.equal(status, 403);
  assert.match(dados.message, /Erro de permissão/i);
  assert.equal(db.boloes.length, 1);
});

test("Definir Resultados deve finalizar partida, calcular pontos e registrar notificacao", async () => {
  const cadastro = await cadastrarUsuario();
  const token = cadastro.dados.token;
  const criado = await criarBolao(token);
  const partidaId = `${criado.dados.bolao.id}-partida-1`;

  db.apostas.push({
    id: "aposta-1",
    bolao_id: criado.dados.bolao.id,
    partida_id: partidaId,
    usuario_id: cadastro.dados.usuario.id,
    placar_time_a: 2,
    placar_time_b: 1,
    pontos: 0,
  });
  db.salvar();

  const { status, dados } = await requisicao(`/partidas/${partidaId}/resultado`, {
    metodo: "PUT",
    token,
    body: {
      resultado_a: 2,
      resultado_b: 1,
    },
  });

  assert.equal(status, 200);
  assert.equal(dados.partida.status, "finalizada");
  assert.equal(dados.partida.resultado_a, 2);
  assert.equal(dados.partida.resultado_b, 1);
  assert.equal(db.apostas[0].pontos, 10);
  assert.equal(db.notificacoes.length, 1);
  assert.equal(dados.ranking[0].pontos, 10);
});

test("Definir Resultados deve rejeitar resultado invalido", async () => {
  const cadastro = await cadastrarUsuario();
  const token = cadastro.dados.token;
  const criado = await criarBolao(token);
  const partidaId = `${criado.dados.bolao.id}-partida-1`;

  const { status, dados } = await requisicao(`/partidas/${partidaId}/resultado`, {
    metodo: "PUT",
    token,
    body: {
      resultado_a: "abc",
      resultado_b: 1,
    },
  });

  assert.equal(status, 400);
  assert.match(dados.message, /Resultado inválido/i);
});

test("Definir Resultados deve bloquear usuario que nao e criador do bolao", async () => {
  const dono = await cadastrarUsuario({
    nome: "Dono",
    email: "dono@email.com",
    senha: "123456",
  });
  const criado = await criarBolao(dono.dados.token);
  const partidaId = `${criado.dados.bolao.id}-partida-1`;

  const outro = await cadastrarUsuario({
    nome: "Outro",
    email: "outro@email.com",
    senha: "123456",
  });

  const { status, dados } = await requisicao(`/partidas/${partidaId}/resultado`, {
    metodo: "PUT",
    token: outro.dados.token,
    body: {
      resultado_a: 1,
      resultado_b: 0,
    },
  });

  assert.equal(status, 403);
  assert.match(dados.message, /Erro de permissão/i);
});
