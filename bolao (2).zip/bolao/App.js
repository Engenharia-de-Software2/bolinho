import React, { useMemo, useState } from "react";
import {
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { StatusBar } from "expo-status-bar";

const API_BASE_URL = Platform.OS === "android" ? "http://10.0.2.2:3000" : "http://localhost:3000";

const CORES = {
  bg: "#F1F5F9",
  card: "#FFFFFF",
  texto: "#0F172A",
  suave: "#64748B",
  borda: "#CBD5E1",
  verde: "#0B3D2E",
  verde2: "#14532D",
  amarelo: "#F2B705",
  perigo: "#DC2626",
  perigoBg: "#FEE2E2",
  sucesso: "#15803D",
  sucessoBg: "#DCFCE7",
};

function Botao({ texto, onPress, tipo = "primario", pequeno = false, disabled = false }) {
  const estilosTipo = {
    primario: { backgroundColor: CORES.verde, color: "#FFFFFF", borderColor: CORES.verde },
    amarelo: { backgroundColor: CORES.amarelo, color: CORES.verde, borderColor: CORES.amarelo },
    perigo: { backgroundColor: CORES.perigo, color: "#FFFFFF", borderColor: CORES.perigo },
    claro: { backgroundColor: "#FFFFFF", color: CORES.verde, borderColor: CORES.borda },
  }[tipo];

  return (
    <TouchableOpacity
      activeOpacity={0.82}
      disabled={disabled}
      onPress={onPress}
      style={[
        styles.botao,
        pequeno && styles.botaoPequeno,
        { backgroundColor: estilosTipo.backgroundColor, borderColor: estilosTipo.borderColor },
        disabled && { opacity: 0.55 },
      ]}
    >
      <Text style={[styles.botaoTexto, { color: estilosTipo.color }]}>{texto}</Text>
    </TouchableOpacity>
  );
}

function Campo({ label, ...props }) {
  return (
    <View style={styles.campoGrupo}>
      <Text style={styles.label}>{label}</Text>
      <TextInput style={styles.input} placeholderTextColor="#94A3B8" {...props} />
    </View>
  );
}

function Aviso({ aviso, limpar }) {
  if (!aviso) return null;
  const erro = aviso.tipo === "erro";

  return (
    <TouchableOpacity
      activeOpacity={0.9}
      onPress={limpar}
      style={[styles.aviso, erro ? styles.avisoErro : styles.avisoSucesso]}
    >
      <Text style={[styles.avisoTexto, erro ? { color: CORES.perigo } : { color: CORES.sucesso }]}>
        {aviso.texto}
      </Text>
    </TouchableOpacity>
  );
}

function Card({ children }) {
  return <View style={styles.card}>{children}</View>;
}

export default function App() {
  const [tela, setTela] = useState("login");
  const [token, setToken] = useState(null);
  const [usuario, setUsuario] = useState(null);
  const [aviso, setAviso] = useState(null);

  const [nome, setNome] = useState("");
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");

  const [nomeBolao, setNomeBolao] = useState("");
  const [tipoBolao, setTipoBolao] = useState("Copa");
  const [descricaoBolao, setDescricaoBolao] = useState("");

  const [boloes, setBoloes] = useState([]);
  const [partidas, setPartidas] = useState([]);
  const [ranking, setRanking] = useState([]);
  const [bolaoAtivoId, setBolaoAtivoId] = useState(null);

  const [resultadoA, setResultadoA] = useState("");
  const [resultadoB, setResultadoB] = useState("");

  const bolaoAtivo = useMemo(
    () => boloes.find((bolao) => bolao.id === bolaoAtivoId) || null,
    [boloes, bolaoAtivoId],
  );

  const partidasDoBolao = useMemo(
    () => partidas.filter((partida) => partida.bolao_id === bolaoAtivoId),
    [partidas, bolaoAtivoId],
  );

  const mostrarAviso = (texto, tipo = "sucesso") => {
    setAviso({ texto, tipo });
  };

  const limparFormularioAuth = () => {
    setNome("");
    setEmail("");
    setSenha("");
  };

  const apiRequest = async (rota, options = {}) => {
    let resposta;

    try {
      resposta = await fetch(`${API_BASE_URL}${rota}`, {
        ...options,
        headers: {
          "Content-Type": "application/json",
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
          ...(options.headers || {}),
        },
      });
    } catch (error) {
      throw new Error("Servidor não respondeu. Rode npm run server antes do npm start.");
    }

    const texto = await resposta.text();
    const dados = texto ? JSON.parse(texto) : {};

    if (!resposta.ok) {
      throw new Error(dados.message || "Erro inesperado");
    }

    return dados;
  };

  // Cadastrar-se
  const cadastrarSe = async () => {
    try {
      const dados = await apiRequest("/auth/register", {
        method: "POST",
        body: JSON.stringify({ nome, email, senha }),
      });

      setToken(dados.token);
      setUsuario(dados.usuario);
      limparFormularioAuth();
      setTela("dashboard");
      mostrarAviso("Conta criada com sucesso. Você foi redirecionado para o menu principal.");
    } catch (error) {
      mostrarAviso(error.message, "erro");
    }
  };

  // Fazer Login
  const fazerLogin = async () => {
    try {
      const dados = await apiRequest("/auth/login", {
        method: "POST",
        body: JSON.stringify({ email, senha }),
      });

      setToken(dados.token);
      setUsuario(dados.usuario);
      limparFormularioAuth();
      setTela("dashboard");
      mostrarAviso("Login realizado com sucesso.");
    } catch (error) {
      mostrarAviso(error.message, "erro");
    }
  };

  // Criar Bolão
  const criarBolao = async () => {
    try {
      const dados = await apiRequest("/boloes", {
        method: "POST",
        body: JSON.stringify({ nome: nomeBolao, tipo: tipoBolao, descricao: descricaoBolao }),
      });

      const bolao = dados.bolao;
      const partidaPadrao = {
        id: `${bolao.id}-partida-1`,
        bolao_id: bolao.id,
        time_a: "Time A",
        time_b: "Time B",
        data_hora: "Data a definir",
        resultado_a: null,
        resultado_b: null,
        status: "agendada",
      };

      setBoloes((lista) => [bolao, ...lista]);
      setPartidas((lista) => [partidaPadrao, ...lista]);
      setNomeBolao("");
      setTipoBolao("Copa");
      setDescricaoBolao("");
      setBolaoAtivoId(bolao.id);
      setTela("bolao");
      mostrarAviso(`Bolão criado. Código: ${dados.codigo_convite}`);
    } catch (error) {
      mostrarAviso(error.message, "erro");
    }
  };

  // Excluir Bolão
  const excluirBolao = async () => {
    if (!bolaoAtivo) return;

    try {
      await apiRequest(`/boloes/${bolaoAtivo.id}`, { method: "DELETE" });

      setBoloes((lista) => lista.filter((bolao) => bolao.id !== bolaoAtivo.id));
      setPartidas((lista) => lista.filter((partida) => partida.bolao_id !== bolaoAtivo.id));
      setBolaoAtivoId(null);
      setTela("dashboard");
      mostrarAviso("Bolão excluído com sucesso.");
    } catch (error) {
      mostrarAviso(error.message, "erro");
    }
  };

  // Definir Resultados
  const definirResultados = async (partida) => {
    try {
      const dados = await apiRequest(`/partidas/${partida.id}/resultado`, {
        method: "PUT",
        body: JSON.stringify({ resultado_a: resultadoA, resultado_b: resultadoB }),
      });

      setPartidas((lista) =>
        lista.map((item) => (item.id === partida.id ? { ...item, ...dados.partida } : item)),
      );
      setRanking(dados.ranking || []);
      setResultadoA("");
      setResultadoB("");
      mostrarAviso("Resultado definido e ranking atualizado.");
    } catch (error) {
      mostrarAviso(error.message, "erro");
    }
  };

  const sair = () => {
    setTela("login");
    setToken(null);
    setUsuario(null);
    setBolaoAtivoId(null);
    setAviso(null);
  };

  return (
    <View style={styles.container}>
      <StatusBar style="light" />
      <View style={styles.topo}>
        <Text style={styles.logo}>Bolão</Text>
        <Text style={styles.subLogo}>Organize seus bolões de forma simples</Text>
      </View>

      <Aviso aviso={aviso} limpar={() => setAviso(null)} />

      <ScrollView contentContainerStyle={styles.conteudo}>
        {tela === "login" && (
          <Card>
            <Text style={styles.titulo}>Fazer Login</Text>
            <Text style={styles.descricao}>Entre com seu e-mail e senha para acessar sua conta.</Text>
            <Campo label="E-mail" value={email} onChangeText={setEmail} autoCapitalize="none" keyboardType="email-address" />
            <Campo label="Senha" value={senha} onChangeText={setSenha} secureTextEntry />
            <Botao texto="Fazer Login" onPress={fazerLogin} />
            <Botao texto="Cadastrar-se" tipo="claro" onPress={() => setTela("cadastro")} />
          </Card>
        )}

        {tela === "cadastro" && (
          <Card>
            <Text style={styles.titulo}>Cadastrar-se</Text>
            <Text style={styles.descricao}>Crie sua conta para começar a usar o bolão.</Text>
            <Campo label="Nome" value={nome} onChangeText={setNome} />
            <Campo label="E-mail" value={email} onChangeText={setEmail} autoCapitalize="none" keyboardType="email-address" />
            <Campo label="Senha" value={senha} onChangeText={setSenha} secureTextEntry />
            <Botao texto="Cadastrar-se" onPress={cadastrarSe} />
            <Botao texto="Voltar ao Login" tipo="claro" onPress={() => setTela("login")} />
          </Card>
        )}

        {tela === "dashboard" && usuario && (
          <>
            <Card>
              <Text style={styles.titulo}>Menu Principal</Text>
              <Text style={styles.descricao}>Usuário logado: {usuario.nome}</Text>
              <Botao texto="Sair" tipo="claro" pequeno onPress={sair} />
            </Card>

            <Card>
              <Text style={styles.titulo}>Criar Bolão</Text>
              <Text style={styles.descricao}>Crie um novo bolão e acompanhe os resultados.</Text>
              <Campo label="Nome do bolão" value={nomeBolao} onChangeText={setNomeBolao} />
              <Campo label="Tipo" value={tipoBolao} onChangeText={setTipoBolao} />
              <Campo label="Descrição" value={descricaoBolao} onChangeText={setDescricaoBolao} />
              <Botao texto="Criar Bolão" onPress={criarBolao} />
            </Card>

            <Card>
              <Text style={styles.titulo}>Meus Bolões</Text>
              {boloes.length === 0 ? (
                <Text style={styles.descricao}>Nenhum bolão criado ainda.</Text>
              ) : (
                boloes.map((bolao) => (
                  <TouchableOpacity
                    key={bolao.id}
                    style={styles.item}
                    onPress={() => {
                      setBolaoAtivoId(bolao.id);
                      setTela("bolao");
                    }}
                  >
                    <Text style={styles.itemTitulo}>{bolao.nome}</Text>
                    <Text style={styles.itemSub}>Código: {bolao.codigo_convite}</Text>
                  </TouchableOpacity>
                ))
              )}
            </Card>
          </>
        )}

        {tela === "bolao" && bolaoAtivo && (
          <>
            <Card>
              <Text style={styles.titulo}>{bolaoAtivo.nome}</Text>
              <Text style={styles.descricao}>Tipo: {bolaoAtivo.tipo}</Text>
              <Text style={styles.codigo}>Código de convite: {bolaoAtivo.codigo_convite}</Text>
              <View style={styles.linhaBotoes}>
                <Botao texto="Voltar" tipo="claro" pequeno onPress={() => setTela("dashboard")} />
                <Botao texto="Excluir Bolão" tipo="perigo" pequeno onPress={excluirBolao} />
              </View>
            </Card>

            <Card>
              <Text style={styles.titulo}>Definir Resultados</Text>
              <Text style={styles.descricao}>Informe o placar final da partida.</Text>
              {partidasDoBolao.map((partida) => (
                <View key={partida.id} style={styles.partidaBox}>
                  <Text style={styles.itemTitulo}>{partida.time_a} x {partida.time_b}</Text>
                  <Text style={styles.itemSub}>Status: {partida.status}</Text>
                  {partida.status === "finalizada" && (
                    <Text style={styles.resultadoFinal}>Resultado: {partida.resultado_a} x {partida.resultado_b}</Text>
                  )}
                  <View style={styles.placarLinha}>
                    <TextInput
                      style={[styles.input, styles.inputPlacar]}
                      placeholder="A"
                      keyboardType="numeric"
                      value={resultadoA}
                      onChangeText={setResultadoA}
                    />
                    <Text style={styles.versus}>x</Text>
                    <TextInput
                      style={[styles.input, styles.inputPlacar]}
                      placeholder="B"
                      keyboardType="numeric"
                      value={resultadoB}
                      onChangeText={setResultadoB}
                    />
                  </View>
                  <Botao texto="Definir Resultados" tipo="amarelo" onPress={() => definirResultados(partida)} />
                </View>
              ))}
            </Card>

            <Card>
              <Text style={styles.titulo}>Ranking atualizado</Text>
              {ranking.length === 0 ? (
                <Text style={styles.descricao}>O ranking aparecerá após definir um resultado.</Text>
              ) : (
                ranking.map((item, index) => (
                  <View key={`${item.email}-${index}`} style={styles.rankingLinha}>
                    <Text style={styles.itemTitulo}>{index + 1}. {item.nome}</Text>
                    <Text style={styles.itemSub}>{item.pontos} pontos</Text>
                  </View>
                ))
              )}
            </Card>
          </>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: CORES.bg,
  },
  topo: {
    backgroundColor: CORES.verde,
    paddingTop: 52,
    paddingBottom: 28,
    paddingHorizontal: 22,
    alignItems: "center",
  },
  logo: {
    color: "#FFFFFF",
    fontSize: 32,
    fontWeight: "900",
  },
  subLogo: {
    color: "#CDE8D5",
    marginTop: 6,
    textAlign: "center",
  },
  conteudo: {
    padding: 18,
    paddingBottom: 40,
    maxWidth: 760,
    width: "100%",
    alignSelf: "center",
  },
  card: {
    backgroundColor: CORES.card,
    borderRadius: 18,
    padding: 18,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: "#E2E8F0",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.08,
    shadowRadius: 12,
    elevation: 2,
  },
  titulo: {
    fontSize: 22,
    fontWeight: "900",
    color: CORES.texto,
    marginBottom: 6,
  },
  descricao: {
    color: CORES.suave,
    marginBottom: 14,
    lineHeight: 20,
  },
  campoGrupo: {
    marginBottom: 12,
  },
  label: {
    fontWeight: "800",
    color: CORES.texto,
    marginBottom: 6,
  },
  input: {
    borderWidth: 1,
    borderColor: CORES.borda,
    backgroundColor: "#F8FAFC",
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 16,
    color: CORES.texto,
  },
  botao: {
    minHeight: 48,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 16,
    borderWidth: 1,
    marginTop: 8,
  },
  botaoPequeno: {
    minHeight: 40,
    paddingHorizontal: 12,
  },
  botaoTexto: {
    fontWeight: "900",
    fontSize: 15,
  },
  aviso: {
    margin: 12,
    marginBottom: 0,
    padding: 12,
    borderRadius: 12,
    borderWidth: 1,
  },
  avisoErro: {
    backgroundColor: CORES.perigoBg,
    borderColor: "#FCA5A5",
  },
  avisoSucesso: {
    backgroundColor: CORES.sucessoBg,
    borderColor: "#86EFAC",
  },
  avisoTexto: {
    fontWeight: "800",
    textAlign: "center",
  },
  item: {
    borderWidth: 1,
    borderColor: "#E2E8F0",
    borderRadius: 14,
    padding: 14,
    marginTop: 10,
    backgroundColor: "#F8FAFC",
  },
  itemTitulo: {
    color: CORES.texto,
    fontWeight: "900",
    fontSize: 16,
  },
  itemSub: {
    color: CORES.suave,
    marginTop: 4,
  },
  codigo: {
    backgroundColor: "#FEF3C7",
    color: "#92400E",
    padding: 10,
    borderRadius: 10,
    fontWeight: "900",
    marginBottom: 12,
  },
  linhaBotoes: {
    gap: 8,
  },
  partidaBox: {
    borderWidth: 1,
    borderColor: "#E2E8F0",
    borderRadius: 14,
    padding: 14,
    backgroundColor: "#F8FAFC",
  },
  placarLinha: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    marginTop: 12,
    marginBottom: 6,
  },
  inputPlacar: {
    flex: 1,
    textAlign: "center",
    fontWeight: "900",
  },
  versus: {
    fontSize: 18,
    fontWeight: "900",
    color: CORES.texto,
  },
  resultadoFinal: {
    color: CORES.sucesso,
    fontWeight: "900",
    marginTop: 8,
  },
  rankingLinha: {
    borderBottomWidth: 1,
    borderBottomColor: "#E2E8F0",
    paddingVertical: 10,
  },
});
